package exceptions;

public class StackIsEmpty extends MyException {
    public StackIsEmpty() {
        super("Stack is empty:");
    }
}
