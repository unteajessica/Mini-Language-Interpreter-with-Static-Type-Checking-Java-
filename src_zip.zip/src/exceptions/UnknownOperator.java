package exceptions;

public class UnknownOperator extends MyException {
    public UnknownOperator() {
        super( "Unknown operator");
    }
}
