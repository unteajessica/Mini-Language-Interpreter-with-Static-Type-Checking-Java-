package exceptions;

public class TypeNotFound extends MyException {
    public TypeNotFound() {
        super("Type not found: ");
    }
}
